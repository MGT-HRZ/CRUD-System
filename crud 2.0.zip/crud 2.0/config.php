<?php 

    //  Connects with the database

    $server = 'localhost';
    $user = 'root';
    $pass = '';
    $dbname = '';

    $connect = mysqli_connect($server, $user, $pass, $dbname);