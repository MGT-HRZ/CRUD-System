<?php 

    //  Add new data to the database

    include 'config.php';

    if (isset($_POST['add'])) {
        $book_id = $_POST['bookid'];
        $book_name = $_POST['bookname'];
        $cate = $_POST['category'];
        $brrwdate = $_POST['brrwdate'];

        $sql = "INSERT INTO buku VALUE ('$book_id', '$book_name', '$cate', '$brrwdate');";

        $result = mysqli_query($connect, $sql);

        if ($result) {
            header('Location: index.php?add-complete');
        }
    }

    
